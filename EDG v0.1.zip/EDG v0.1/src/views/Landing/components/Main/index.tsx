import React from "react";
import { Link } from "@material-ui/core";
import "./main.scss";
import Background from "../../../../assets/icons/bsc33-homepage.png";

var sectionStyle = {
    backgroundImage: `url(${Background})`,
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    width: '480px',
    height: '237px',
    margin: 0,
};

function Main() {

    return (
        <div className="landing-main">
            <div className="landing-main-title-wrap" style={sectionStyle}>
            </div>
            <div className="landing-main-title-wrap">
                <p>EDG</p>
            </div>
            <div className="landing-main-help-text-wrap">
                <p>Financial tools to grow your wealth - stake</p>
                <p>and earncompounding interest</p>
            </div>
            <div className="landing-main-btns-wrap">
                <Link href="https://app.edgwin.finance" target="_blank" rel="noreferrer">
                    <div className="landing-main-btn">
                        <p>Enter APP</p>
                    </div>
                </Link>
            </div>
        </div>
    );
}

export default Main;
