import { Networks } from "../../constants/blockchain";
import { LPBond, CustomLPBond } from "./lp-bond";
import { StableBond, CustomBond } from "./stable-bond";
import { getAddresses } from "../../constants";

import MimIcon from "../../assets/tokens/MIM.svg";
import AvaxIcon from "../../assets/tokens/AVAX.svg";
import MimTimeIcon from "../../assets/tokens/MIM.svg";
import AvaxTimeIcon from "../../assets/tokens/TIME-AVAX.svg";

import { StableBondContract, LpBondContract, WavaxBondContract, StableReserveContract, LpReserveContract } from "../../abi";

export const mim = new StableBond({
    name: "BUSD",
    displayName: "BUSD",
    bondToken: "BUSD",
    bondIconSvg: MimIcon,
    bondContractABI: StableBondContract,
    reserveContractAbi: StableReserveContract,
    networkAddrs: {
        [Networks.BSC]: {
            bondAddress: getAddresses(Networks.BSC).BUSD_BOND_ADDRESS,
            reserveAddress: getAddresses(Networks.BSC).BUSD_RESERVE_ADDRESS,
        },
    },
});

export const mimTime = new LPBond({
    name: "busd_edg_lp",
    displayName: "EDG-BUSD LP",
    bondToken: "BUSD",
    bondIconSvg: MimTimeIcon,
    bondContractABI: LpBondContract,
    reserveContractAbi: LpReserveContract,
    networkAddrs: {
        [Networks.BSC]: {
            bondAddress: getAddresses(Networks.BSC).BUSD_LP_BOND_ADDRESS,
            reserveAddress: getAddresses(Networks.BSC).BUSD_SWAP_ADDRESS,
        },
    },
    lpUrl: "https://pancakeswap.finance/swap?outputCurrency=0x25559A80e1f6E0D6Db28848003716a555727Ca55&inputCurrency=0xe9e7cea3dedca5984780bafc599bd69add087d56",
});

export default [mim, mimTime];
