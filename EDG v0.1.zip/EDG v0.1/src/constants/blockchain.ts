export const TOKEN_DECIMALS = 9;

export enum Networks {
    BSC = 56,
}

export const DEFAULD_NETWORK = Networks.BSC;
