export const getMainnetURI = (): string => {
    return "https://speedy-nodes-nyc.moralis.io/c9ca5d7e666a737cc53fa7e6/bsc/mainnet";
};
